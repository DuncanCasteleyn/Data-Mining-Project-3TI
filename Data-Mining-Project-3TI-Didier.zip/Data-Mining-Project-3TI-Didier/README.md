# Data-Mining-Project-3TI
Data mining project for 3TI
